from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import time
import threading
from datetime import datetime, timezone, timedelta
import psycopg2
from psycopg2 import Error
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
import json
import os
from dotenv import load_dotenv
import logging

load_dotenv()  # Load environment variables from the .env file
app = Flask(__name__)
CORS(app)

api_response_data = {}

# Use environment variables for sensitive information
DB_USER = os.environ.get('DB_USER')
DB_PASSWORD = os.environ.get('DB_PASSWORD')
DB_HOST = os.environ.get('DB_HOST')
DB_PORT = os.environ.get('DB_PORT')
DB_NAME = os.environ.get('DB_NAME')
COGNITO_USER_POOL_ID = os.environ.get('COGNITO_USER_POOL_ID')
COGNITO_CLIENT_ID = os.environ.get('COGNITO_CLIENT_ID')
# Set up the logger configuration
logging.basicConfig(
    level=logging.ERROR,  # Set the logging level to ERROR or higher
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='error.log',  # Specify the log file name
    filemode='a'  # Append to the log file
)

logger = logging.getLogger(__name__)



@app.route('/get_ids', methods=['GET'])
def get_ids():
    response = {
        "userPoolId": COGNITO_USER_POOL_ID,
        "clientId": COGNITO_CLIENT_ID
    }
    return jsonify(response)


def create_table():
    try:
        connection = psycopg2.connect(user=DB_USER,
                                      password=DB_PASSWORD,
                                      host=DB_HOST,
                                      port=DB_PORT,
                                      database=DB_NAME)

        connection.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = connection.cursor()

        create_table_query = '''
        CREATE TABLE IF NOT EXISTS api_responses (
        id SERIAL PRIMARY KEY,
        thread_id BIGINT,
        timestamp TIMESTAMP,
        api_endpoint VARCHAR(255),
        user_email VARCHAR(255),
        call_number INTEGER,
        response_data JSONB
        );
        '''
        cursor.execute(create_table_query)
        cursor.close()
        print("table created successfully")
    except (Exception, Error) as e:
        logging.error("Error creating the table: %s", e)
        print("table not created")


def get_pakistan_time():
    utc_time = datetime.utcnow()
    pakistan_time = utc_time.replace(tzinfo=timezone.utc).astimezone(timezone(timedelta(hours=5)))
    return pakistan_time.strftime('%Y-%m-%d %H:%M:%S')


def call_api(endpoint, frequency, duration, user_email):
    # Generate a unique thread ID for each call_api thread
    thread_id = threading.current_thread().ident
    try:
        interval = 3600 / frequency  # Convert frequency to seconds
        end_time = time.time() + (duration * 3600)

        call_number = 0  # Initialize the call number

        while time.time() < end_time:
            call_number += 1
            response = requests.get(endpoint)
            if response.ok:
                api_response_data.clear()
                current_time = get_pakistan_time()  # Get Pakistan time
                api_response_data[current_time] = response.json()
                response_data_json = json.dumps(api_response_data[current_time])
                logger.info(api_response_data)
                print(api_response_data)

                # Insert data into the database
                try:
                    connection = psycopg2.connect(user=DB_USER,
                                                  password=DB_PASSWORD,
                                                  host=DB_HOST,
                                                  port=DB_PORT,
                                                  database=DB_NAME)

                    cursor = connection.cursor()
                    
                    insert_query = '''
                    INSERT INTO api_responses (thread_id, timestamp, api_endpoint, call_number, user_email, response_data)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    '''
                    data = (thread_id, current_time, endpoint, call_number, user_email, response_data_json)  # Include user_email
                    cursor.execute(insert_query, data)
                    connection.commit()
                    cursor.close()

                except (Exception, Error) as e:
                    logging.error("Error inserting data into the table: %s", e)
                    print("error inserting data")
            time.sleep(interval)

    except Exception as e:
        logging.error("Error calling API: %s", e)
        print("error calling api")


@app.route('/api/call_api', methods=['POST'])
def start_api_calls():
    try:
        data = request.get_json()
        api_endpoint = data['apiEndpoint']
        frequency = int(data['frequency'])
        duration = float(data['duration'])
        user_email = data['userEmail'] 

        # Check if the API endpoint is valid
        response = requests.get(api_endpoint)
        print(response)
        if not response.ok:
            return jsonify({'error': 'Invalid API endpoint', 'status_code': response.status_code})

        # Clear previous response data before starting new API calls
        api_response_data.clear()
        
        # Create a new thread to call the API with user-defined parameters
        inputs = (api_endpoint, frequency, duration, user_email)  # Include user_email
        thread = threading.Thread(target=call_api, args=inputs)
        thread.start()


        return jsonify({'message': 'API calls started successfully!'})
    except Exception:
        return jsonify({'error': 'Invalid input or failed to start API calls.'})

@app.route('/api/get_latest_data', methods=['GET'])
def get_response_data():
    try:
        api_endpoint = request.args.get('apiEndpoint')
        user_email = request.args.get('userEmail')
        # Check if the API endpoint is provided
        if not api_endpoint:
            return jsonify({'message': 'Please provide the API endpoint'})

        # Connect to the database
        connection = psycopg2.connect(user=DB_USER,
                                      password=DB_PASSWORD,
                                      host=DB_HOST,
                                      port=DB_PORT,
                                      database=DB_NAME)

        cursor = connection.cursor()

        # Query to fetch all data from the table that corresponds to the provided API endpoint        
        select_query = '''
        SELECT * FROM api_responses WHERE api_endpoint = %s AND user_email = %s ORDER BY timestamp DESC;
        '''
        cursor.execute(select_query, (api_endpoint, user_email))
        
        api_responses = cursor.fetchall()

        # Close the cursor and connection
        cursor.close()
        connection.close()

        # Check if any data is returned
        if not api_responses:
            return jsonify({'message': 'No data found for the provided API endpoint'})

        return jsonify(api_responses)

    except (Exception, Error):
        print("failed to fetch data")
        return jsonify({'error': 'Failed to fetch data from the database.'})


if __name__ == '__main__':
    create_table()
    app.run(debug=True, host='0.0.0.0', port=5000) 
